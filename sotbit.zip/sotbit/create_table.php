<?php

function create_table($host, $user, $password, $database) {
$link = mysqli_connect($host, $user, $password, $database);
$query = "CREATE TABLE IF NOT EXISTS parse_table (
    product_id INT NOT NULL AUTO_INCREMENT,
    sku varchar(50) NOT NULL DEFAULT '',
    product text NOT NULL DEFAULT '',
    internet_price int,
    balance smallint,
    PRIMARY KEY(product_id)
    );";
    
$result = mysqli_query($link, $query) or die("Ошибка " . mysqli_error($link));
if($result)
{
    echo "Создание таблицы прошло успешно";
}
mysqli_close($link);
}


// echo "<button><a href="">Вернуться</a></button>";