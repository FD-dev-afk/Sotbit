<?php

require 'excel_reader/vendor/autoload.php';

use \PhpOffice\PhpSpreadsheet\Shared\Date;

$file='parser_info/parser.xls';
$excel = \PhpOffice\PhpSpreadsheet\IOFactory::load($file);

$excel->setActiveSheetIndex(0);

$sheet = $excel->getActiveSheet();

$letters = [];
$model_columns = $_POST['model'];
$column = $_POST['column_number'];
$count = 1;
if(isset($_POST['column_count'])) {
    $count = $_POST['column_count'];
}


$separeted_columns = implode(',', $model_columns);
if(in_array('sku', $model_columns)) {$letters[] = 'A';}
if(in_array('product', $model_columns)) {$letters[] = 'B';}
if(in_array('internet_price', $model_columns)) {$letters[] = 'C';}
if(in_array('balance', $model_columns)) {$letters[] = 'D';}



//ВПИШИТЕ СВОЮ БД ПАРОЛЬ ХОСТ И ПОЛЬЗОВАТЕЛЯ
$link = mysqli_connect('sotbit', 'root', '', 'mybd');
for ($i = 0; $i < $count; $i++)
{
    $values = [];
    foreach ($letters as $letter) {
        $cell = $sheet->getCell("$letter$column");
        if (is_string($cell->getValue())) {
                $values[] = "'".$cell->getValue()."'";
        } else {
        $values[] = $cell->getValue();
        }
    }
    $str = implode(',', $values);
    $query = "INSERT INTO parse_table($separeted_columns) VALUES ($str);";
    $result = mysqli_query($link, $query) or die("Ошибка " . mysqli_error($link));
    $column++;
}

mysqli_close($link);

// $a = 2;
// $type = 'A';
// $cell = $sheet->getCell("$type$a");
// echo $cell->getValue();