<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parser</title>
</head>
<body>
    <form action="parser.php" method="POST" name="info_form">
    <p>Выберите поле модели: <br>
        <br>
        <select name="model[]" size="4" multiple="multiple">
            <option value="sku">sku</option>
            <option value="product">product</option>
            <option value="internet_price">internet_price</option>
            <option value="balance">balance</option>
        </select></p>
        <p>Номер колонки <br>
        <input type="text" name="column_number">
        </p>
        <p>Количество записей <br>
        <input type="text" name="column_count">
        </p>
        <input type="submit" value="Парсить">
    </form>

    <br><br>

    <p>Обязательная форма:</p>
    <form action="connection.php" method="POST" name="connect_form" style="border: 2px solid black; width:200px; height:270px; padding-left:10px;">
        <p> Имя хоста: <br>
        <input type="text" name="host">
        </p>
        <p> База данных: <br>
        <input type="text" name="database">
        </p>
        <p> Имя пользователя: <br>
        <input type="text" name="user">
        </p>
        <p> Пароль от базы данных: <br>
        <input type="text" name="password">
        </p>
        <input type="submit" value="Создать таблицу">
    </form>

</body>
</html>