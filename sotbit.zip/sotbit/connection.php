<?php

require_once 'create_table.php';

 $host=$_POST['host'];
 $database=$_POST['database'];
 $user=$_POST['user'];
 if (isset($_POST['password'])){
 $password=$_POST['password'];
 } else {
    $password='';
 }

 create_table($host, $user, $password, $database);

echo '<button><a href="parser_interface.php">Вернуться</a></button>';
